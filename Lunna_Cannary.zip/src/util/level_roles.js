const starter = 1000;

function calcular_xp(level) {
const xp_needed = starter * level;

return xp_needed;
}

module.exports = calcular_xp;